package stepDefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import accelarators.FL_ActionClass;
import accelarators.FL_Base;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.FL_PageObjects;

public class FL_StepDefinitions {
	
	WebDriver driver = FL_Base.launchBrowser();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	
	@Given("I navigate to demowebshop website")
	public void i_navigate_to_demowebshop_website() {
	    driver.get("https://demowebshop.tricentis.com/");
	}
	@And("I click register on top of the page next to login")
	public void i_click_register_on_top_of_the_page_next_to_login() {
	   FL_ActionClass.clickOnElement(FL_PageObjects.registerlink, "Register link");
	}
	@When("I register a new user with {string} and {string}")
	public void i_register_a_new_user_with_and(String sEmail, String sPassword) throws Throwable {
		
		
		FL_ActionClass.clickRadioButton(FL_PageObjects.maleRadioButton, "male radio button");
		FL_ActionClass.typeInTextBox(FL_PageObjects.firstNameTextField, "Ndalo","FirstName textfield");
		FL_ActionClass.typeInTextBox(FL_PageObjects.lastNameTextField, " Hlazo", "Last Name textfield");
		FL_ActionClass.typeInTextBox(FL_PageObjects.emailAdressTextField, sEmail, "email address text field");
		FL_ActionClass.typeInTextBox(FL_PageObjects.passwordAdressTextField, sPassword, "password text field");
		FL_ActionClass.typeInTextBox(FL_PageObjects.confirmTextField, "123456789", "confirm password textfield");
		FL_ActionClass.clickOnElement(FL_PageObjects.registerButton, "Register Button");
		Thread.sleep(1000);
		FL_ActionClass.clickOnElement(FL_PageObjects.logoutLabel,"Log Out label");
			
	}
	@Then("I login with {string} and {string}")
	public void i_login_with_and(String sEmail, String sPassword) throws Throwable {
		FL_ActionClass.clickOnElement(FL_PageObjects.loginLabel,"Log In label");
		FL_ActionClass.typeInTextBox(FL_PageObjects.emailAdressTextField, sEmail, "email address text field");
		FL_ActionClass.typeInTextBox(FL_PageObjects.passwordAdressTextField, sPassword, "password text field");
		FL_ActionClass.clickOnElement(FL_PageObjects.loginButton, "Login Button");
		Thread.sleep(5000);
	}

    @When("I click login link")
    public void i_click_login_link() {
    	FL_ActionClass.clickOnElement(FL_PageObjects.loginLink,"login link");
     }

	@And("I click on Computers tab")
	public void i_click_on_computers_tab() {
	
		FL_ActionClass.clickOnElement(FL_PageObjects.computerTab,"computer tab");
		FL_ActionClass.clickOnElement(FL_PageObjects.desktopLink, "Desktops links");
	}
	@And("I select the Desktops option")
	public void i_select_the_desktops_option() {
	   FL_ActionClass.hovering(FL_PageObjects.computerTab);
	   FL_ActionClass.selectOption(FL_PageObjects.desktopOtion,"Desktops");
	}
	@And("I sort desktops by all available options")
	public void i_sort_desktops_by_all_available_options() {
		
		FL_ActionClass.Sort(FL_PageObjects.sortDropdown);
		FL_ActionClass.clickOnElement(FL_PageObjects.addToCartButton,"Add to cart");
		
		
	}
	@When("I add all desktop items to the cart")
	public void i_add_all_desktop_items_to_the_cart() throws InterruptedException {
		
		
		 System.out.print("Adding Desktop to cart");
		 FL_ActionClass.clickOnElement(FL_PageObjects.addToCartButton1,"add button 1");
		 FL_ActionClass.clickRadioButton(FL_PageObjects.processorSlowrdbn, "Select Processor");
		 FL_ActionClass.clickRadioButton(FL_PageObjects.radioButtonR, "Select RAM");
		 FL_ActionClass.clickRadioButton(FL_PageObjects.radioButtonHDD, "Select HDD");
		 FL_ActionClass.clickOnElement(FL_PageObjects.addToCartButton1,"add to cart button 1");	 
		
		 Thread.sleep(1000);
			
		 FL_ActionClass.addCartButton(FL_PageObjects.addToCartButton,"add to cart buttons ");	
		 Thread.sleep(2000);
		 
		 wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("bar-notification")));
		FL_ActionClass.clickOnElement(FL_PageObjects.shopCartLink,"shopping cart link");
		 
	}
	@And("I validate the total price in the cart")
	public void i_validate_the_total_price_in_the_cart() {

		FL_ActionClass.validateTotal(FL_PageObjects.allItemsCart,"validate total");
	
	}
	@And("I remove one item from the cart")
	public void i_remove_one_item_from_the_cart() {
		//FL_ActionClass.removeItem(FL_PageObjects.cartRows);
	}
	@And("I validate the updated total price in the cart")
	public void i_validate_the_updated_total_price_in_the_cart() {
	    
	}
	@And("I proceed to checkout")
	public void i_proceed_to_checkout() {
		FL_ActionClass.selectDopDown(FL_PageObjects.stateDropdown,"South Africa");
		FL_ActionClass.clickCheckbox(FL_PageObjects.termsCheckbox,"agree terms checkbox");
		FL_ActionClass.clickOnElement(FL_PageObjects.checkoutButton,"check out button");
	}
	@When("I fill in all required information and complete the transaction")
	public void i_fill_in_all_required_information_and_complete_the_transaction() {
	   
	}
	@Then("I navigate to My Account")
	public void i_navigate_to_my_account() {
	    
	}
	@And("I validate the order is created successfully")
	public void i_validate_the_order_is_created_successfully() {
	 
	}




}
