package accelarators;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;



public class FL_ActionClass extends FL_Base {
	
	
	public static boolean clickOnElement(By object, String elementName) {
	    boolean bFlag = false;
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(object));
	        element.click();
	        System.out.println("Successfully clicked on: " + elementName);
	        bFlag = true;
	    } catch (TimeoutException e) {
	        Assert.fail("Failed to click on '" + elementName + "' due to timeout: " + e.getMessage());
	    } catch (NoSuchElementException e) {
	        Assert.fail("Element '" + elementName + "' not found: " + e.getMessage());
	    } catch (Exception e) {
	        Assert.fail("Failed to click on '" + elementName + "' due to an unexpected error: " + e.getMessage());
	    }
	    return bFlag;
	}

	
	//Function to type in text box 
	public static void typeInTextBox(By object,String data,String elementName) {
		try {
			if(driver.findElement(object).isDisplayed()) {
				driver.findElement(object).clear();
				driver.findElement(object).sendKeys(data);	
			}
		}
		catch (Exception e) {
			Assert.fail("Failed to enter data in "+elementName+" textbox");
		}
	}
	//Function to click radio button
	public  static boolean clickRadioButton(By object,String element) {
		
		boolean bFlag  = false;
		
		try {
			 
			if (!driver.findElement(object).isSelected())
			driver.findElement(object).click();
			return true;
		}
		catch(Exception e) {
			Assert.fail("Failed to select radio button");
		}
		return bFlag;
		
	}
	//Function to click options
	
	public static void hovering(By object) {
	    
	    WebElement computersTab = driver.findElement(object);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(computersTab).perform();

	}
	public static void selectOption(By object,String element) {
		WebElement desktopsOption = driver.findElement(object);

	    desktopsOption.click();
	}
      
	
      //SORT
     public static void Sort(By object) {
      
            
             // Locate the "Sort by" dropdown
             WebElement sortByDropdown = driver.findElement(object);
             
             Select dropdown = new Select(sortByDropdown);
             
            	  
            	    // Get all options
            	    List<WebElement> allOptionsElement = dropdown.getOptions();

            	    // Extract text and sort the options

            	    // Creating a list to store drop down options
            	    List options = new ArrayList();
            	    
            	    for (WebElement option : allOptionsElement) {
            	    	  options.add(option.getText());
            	    }
            	    // Removing "Please select" option as it is not actual option
            	    options.remove("Please select");
            	    // Creating a temp list to sort
            	    List tempList = new ArrayList(options);

            	    Collections.sort(tempList);

            	    System.out.println("Sorted List "+ tempList);

            	    boolean ifSortedAscending = options.equals(tempList);

            	    if(ifSortedAscending)
            	    {
            	        System.out.println("List is sorted");
            	    }
            	    else
            	        System.out.println("List is not sorted.");

            	   
       }
            	
public static void validateTotal(By object,String element) {
	SoftAssert softAssert = new SoftAssert();
	
	 double expectedTotalPrice = 0.0;
   
	try{// Locate the total price element
    
    List<WebElement> totalPriceElement = driver.findElements(object);
    // Get the text of the total price
 
    
 // Calculate the sum of the prices of all items
    
    
    for (WebElement priceElement : totalPriceElement) {
    	
        String priceText = priceElement.getText().trim();
        
        priceText = priceText.replaceAll("[^0-9.]", ""); // Remove non-numeric characters
        
        if (!priceText.isEmpty()) {
            expectedTotalPrice += Double.parseDouble(priceText); // Add to total
        }
    }
    // Print the expected total price for debugging
    System.out.println("Expected Total Price (sum of item prices): " + expectedTotalPrice);

    // Locate the total price element displayed on the page
    WebElement total = driver.findElement(By.xpath("//span[@class='product-price order-total']"));
    String totalPriceText = total.getText().trim();
    
    // Extract numerical value from the displayed total (remove non-numeric characters)
    totalPriceText = totalPriceText.replaceAll("[^0-9.]", "");

    // Check if the total price text is empty
    if (totalPriceText.isEmpty()) {
        System.out.println("Total price element is empty or not visible.");
        Assert.fail("Total price element is empty or not visible.");
        return;
    }

    // Parse the actual total price
    double actualTotalPrice = Double.parseDouble(totalPriceText);

    if (actualTotalPrice != expectedTotalPrice) {
        System.out.println("Total price mismatch!");
        Assert.fail("Total price does not match.");
               }
	 } catch (Exception e) {
	        // Catch and log the exception, but continue with the test
	        System.out.println("Error occurred: " + e.getMessage());
   }
	softAssert.assertAll();

}

public static void addCartButton(By object, String element) {
	
    	Actions action  = new Actions(driver);
    	
        // Find all buttons with the specified locator
        List<WebElement> buttons = driver.findElements(object);
        System.out.print(buttons);

        // Iterate through the buttons and click each one
        for (int i = 0; i < buttons.size(); i++) {
        	action.moveToElement(buttons.get(i)).click().perform();
        }
        
}  
        

//Select value from drop down using visible text
	public static boolean selectByValue(By objElement, String sValue)
			throws Throwable {
		boolean bflag=false;
		try {
			Select s = new Select(driver.findElement(objElement));
			s.selectByValue(sValue);
			bflag = true;
			return bflag;
		} catch (Exception e) {
			return false;
		}
	}

public static void clickCheckbox(By Object, String element) {
	  try {
          WebElement checkbox = driver.findElement(Object);
          
          // If the checkbox is not already selected, click it
          if (!checkbox.isSelected()) {
              checkbox.click();
              System.out.println("Checkbox clicked successfully.");
          } else {
              System.out.println("Checkbox is already selected.");
          }
      } catch (Exception e) {
          System.out.println("Error occurred while clicking the checkbox: " + e.getMessage());
      }
  }
	
public static void selectDopDown(By Object, String value) {
	 try {
         WebElement dropdownElement = driver.findElement(Object);
         Select dropdown = new Select(dropdownElement);
         
         // Select by value (value attribute of the option)
         dropdown.selectByValue(value);
         System.out.println("Option selected by value: " + value);
     } catch (Exception e) {
         System.out.println("Error occurred while selecting an option by value: " + e.getMessage());
     }
 }
        
   
 }
	

	
	
	
	
	
	
	
	
	
     


