package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class FL_PageObjects {
	
	// Locators
        public static By registerlink = By.xpath("//*[contains(text(), 'Register')]");
        public static By maleRadioButton = By.xpath("//input[@id='gender-female']");
        public static By firstNameTextField= By.xpath("//input[@id='FirstName']");
        public static By lastNameTextField= By.xpath("//input[@id='LastName']");
        public static By emailAdressTextField= By.xpath("//input[@id='Email']");
        public static By loginButton = By.xpath("//input[@value='Log in']");
        public static By passwordAdressTextField= By.xpath("//input[@id='Password']");
        public static By confirmTextField= By.xpath("//input[@id='ConfirmPassword']");
        public static By registerButton= By.xpath("//input[@id='register-button']");
		public static  By sortDropdown = By.id("products-orderby");
	    public static  By desktopItems = By.xpath("//input[@value='Add to cart']");
		public static  By priceSelector = By.cssSelector(".prices .price");
		public static  By addToCartButton = By.xpath("//input[@value='Add to cart']");
		public static  By successNotification = By.cssSelector(".bar-notification.success");
		public static  By notificationCloseButton = By.cssSelector(".bar-notification .close");
		public static  By totalPrice = By.xpath("//span/span[@class='product-price order-total']/strong");
		public static  By updateCartButton = By.name("updatecart");
		public static  By loginLink = By.className("ico-login");
		public static  By computerTab = By.xpath("(//*[contains(text(),'Computers')])[1]");
		public static  By desktopOtion = By.linkText("Desktops");
		public static  By totalPriceLocator = By.cssSelector(".cart-total .total-price-value");
		public static By removeButtonItem = By.cssSelector(".remove-btn");
		public static By desktoplist = By.xpath("https://demowebshop.tricentis.com/desktops?orderby");
		public static By sortBy     = By.id("products-orderby");
		public static By desktopLink = By.xpath("(//a[@href='/desktops'])[4]");
		
		public static By cartRows = By.className("cartRows");
		public static By logoutLabel = By.xpath("//a[@class='ico-logout']");
		public static By loginLabel = By.xpath("//a[@class='ico-login']");
		public static By addToCartButton1 = By.xpath("(//input[@value='Add to cart'])[1]");
		public static By addToCartButton2 = By.xpath("(//input[@value='Add to cart'])[2]");
		public static By addToCartButton3 = By.xpath("(//input[@value='Add to cart'])[3]");
		public static By processorSlowrdbn = By.xpath("(//input[@type='radio'])[1]");
		public static By radioButtonR= By.xpath("(//input[@type='radio'])[4]");
		public static By radioButtonHDD= By.xpath("(//input[@type='radio'])[6]");
		public static By shopCartLink = By.xpath("(//*[contains(text(), 'Shopping cart')])[1]");
		public static By productTitle = By.xpath("(//h2[@class='product-title'])[1]");
		public static By checkoutButton = By.xpath("//button[@id='checkout']");
		public static By allItemsCart = By.className("product-price");
		public static By selectCountrydrop =By.className("country-input");
		public static By stateDropdown =By.className("state-input");
		public static By termsCheckbox = By.xpath("(//input[@type='checkbox'])[2]");
		
    	
		
		
		
		//div[@id='parent']/span[1]
}
